import json
import pokedex
import pygame
import random

pygame.init()
pygame.font.init()

font = pygame.font.Font('Pokemon GB.ttf', 15)
black = (0, 0, 0)
window_surface = pygame.display.set_mode((600, 700))
pokemon_list = open("pokemon.txt").read().split()
rects = []

party = []
FPS = 60
titty = pygame.time.Clock()
first = True
with open('move') as json_file:
    moves = json.load(json_file)
list = []
for i in pokemon_list:
    expanded_pokemon = i.split(",")
    list.append([expanded_pokemon[0], expanded_pokemon[1], expanded_pokemon[2]])


for j in range(len(pokemon_list)):
    for move in moves:
        move_type = moves[move]["type"].capitalize()
        if list[j][1] == move_type or list[j][2] == move_type:
            list[j].append(moves[move])

with open("pokemon movesets", "w") as file:
    json.dump(list, file)


def battle_sequence(starter_choice, backpack, is_battle):
    global first, party
    if first:
        image = pygame.image.load(r'images/' + str(starter_choice) + '.png')
        image = pygame.transform.flip(image, True, False)
        expanded_starter = pokemon_list[starter_choice - 1].split(",")
        start_pokemon = {
            "image": image,
            "name": expanded_starter[0],
            "lv": 5,
            "hp": expanded_starter[8],
            "moves": []
        }
        party = [start_pokemon]
        first = False
    print(moves)
    wild_num = random.randint(0, 150) + 1
    while is_battle:
        titty.tick(FPS)
        mouse_x, mouse_y = pygame.mouse.get_pos()
        window_surface.fill(black)
        window_surface.fill(pygame.Color('darkgreen'), pygame.Rect(0, 0, 600, 350))
        pygame.draw.circle(window_surface, (166, 118, 92, 255), (100, 1000), 700)
        new_pokemon = pygame.image.load(r'images/' + str(wild_num) + '.png')
        expanded_enemy = pokemon_list[wild_num - 1].split(",")
        enemy_pokemon = {
            "image": new_pokemon,
            "name": expanded_enemy[0],
            "lv": random.randint(1,100),
            "hp": expanded_enemy[8],
            "moves": []
        }
        window_surface.blit(party[0]["image"], (40, 235))
        pygame.draw.ellipse(window_surface, (166, 118, 92, 255), pygame.Rect(300, 120, 300, 80))
        window_surface.fill(pygame.Color('lightblue'), pygame.Rect(0, 0, 600, 100))
        window_surface.blit(enemy_pokemon["image"], (400, 70))
        window_surface.blit(pygame.image.load('battle_text.png'), (0, 350))
        fight_rect = pygame.Rect((67, 427, 533 - 67, 575 - 427))
        bag_rect = pygame.Rect((5, 619, 176 - 5, 691 - 619))
        run_rect = pygame.Rect((216, 633, 383 - 216, 698 - 633))
        pokemon_button_rect = pygame.Rect((423, 620, 588 - 423, 689 - 620))
        bag = False
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                is_battle = False
        if True in pygame.mouse.get_pressed():
            if pygame.Rect.collidepoint(fight_rect, (mouse_x, mouse_y)):
                print("fight")
            if pygame.Rect.collidepoint(bag_rect, (mouse_x, mouse_y)):
                bag = True
            if pygame.Rect.collidepoint(run_rect, (mouse_x, mouse_y)):
                is_battle = False
            if pygame.Rect.collidepoint(pokemon_button_rect, (mouse_x, mouse_y)):
                print("pokemon")
            while bag:
                mouse_x, mouse_y = pygame.mouse.get_pos()
                bag_items = list(backpack.keys())
                bag_ammounts_images = list(backpack.values())
                item_rects = []
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        bag = False
                        is_battle = False
                pygame.draw.rect(window_surface, pygame.Color("Grey"), pygame.Rect(0, 350, 600, 350))
                pygame.draw.rect(window_surface, (255, 0, 0), pygame.Rect(0, 350, 600, 20))
                for i in range(len(bag_items)):
                    if bag_ammounts_images[i][0] > 0:
                        bag_text = font.render(bag_items[i] + " : " + str(bag_ammounts_images[i][0]), True, (0, 0, 0))
                        window_surface.blit(bag_text, (10, 380 + 50 * i))
                        image = pygame.image.load(bag_ammounts_images[i][1])
                        image = pygame.transform.scale(image, (50, 50))
                        window_surface.blit(image, (500, 375 + 50 * i))
                        item_rects.append(pygame.Rect(10, 380 + 50 * i, 600, 50))
                    else:
                        del backpack[bag_items[i]]
                for rect in item_rects:
                    if True in pygame.mouse.get_pressed():
                        if pygame.Rect.collidepoint(rect, (mouse_x, mouse_y)):
                            if bag_ammounts_images[item_rects.index(rect)][1] == "pokeball.png":
                                backpack["pokeball"][0] -= 1
                                if random.randint(1, 50) <= 2:
                                    party.append(enemy_pokemon)
                                    is_battle = False
                                    pygame.time.wait(20)
                            elif bag_ammounts_images[item_rects.index(rect)][1] == "great_ball.png":
                                backpack["great ball"][0] -= 1
                                if random.randint(1, 25) <= 2:
                                    party.append(enemy_pokemon)
                                    is_battle = False
                                    pygame.time.wait(20)
                            elif bag_ammounts_images[item_rects.index(rect)][1] == "ultra_ball.png":
                                backpack["ultra ball"][0] -= 1
                                if random.randint(1, 15) <= 2:
                                    party.append(enemy_pokemon)
                                    is_battle = False
                                    pygame.time.wait(20)
                            bag = False
                pygame.display.flip()
        pygame.display.flip()
    pygame.display.flip()
